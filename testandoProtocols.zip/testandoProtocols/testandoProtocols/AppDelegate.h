//
//  AppDelegate.h
//  testandoProtocols
//
//  Created by Jonas Junior on 19/08/21.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

