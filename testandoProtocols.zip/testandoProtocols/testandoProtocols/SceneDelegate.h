//
//  SceneDelegate.h
//  testandoProtocols
//
//  Created by Jonas Junior on 19/08/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

